package com.jpa.objects;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the testtab database table.
 * 
 */
@Entity
@NamedQuery(name="Testtab.findAll", query="SELECT t FROM Testtab t")
public class Testtab implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private Integer age;

	private String name;

	public Testtab() {
	}
	
	

	public Testtab(Integer age, String name) {
		super();
		this.age = age;
		this.name = name;
	}



	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Testtab [id= " + id + ", age = " + age + ", name = " + name + "]";
	}
	
	

}