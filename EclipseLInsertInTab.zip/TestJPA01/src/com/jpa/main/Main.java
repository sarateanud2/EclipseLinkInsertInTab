package com.jpa.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jpa.objects.Testtab;

public class Main {

	public static void main(String[] args) {
		
		Testtab t1 = new Testtab(18, "Florin");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("TestJPA01");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(t1);
		tx.commit();
		em.close();
		emf.close();
		
	}

}
